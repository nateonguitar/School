package cardgame.cards;

public interface Game{
	public void initialize();
	public void play();
	public void displayWinner();
}
