package cardgame.cards;

public class Hand extends GroupOfCards{
	public Hand(){
		super();
	}
}
