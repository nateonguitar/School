package cardgame.cards;

public enum Suits {
	HEARTS, DIAMONDS, CLUBS, SPADES
}
