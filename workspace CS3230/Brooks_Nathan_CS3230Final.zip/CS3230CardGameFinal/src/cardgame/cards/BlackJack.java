package cardgame.cards;

import java.io.IOException;

import javafx.application.Application;
import javafx.stage.Stage;

public class BlackJack extends Application{
	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args) {
        launch(args);
    }
}
